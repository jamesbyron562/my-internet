﻿namespace InternetCafeMS
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            panelMain = new Panel();
            panelLeft = new Panel();
            picLogo = new PictureBox();
            lblBrand = new Label();
            lblTagline = new Label();
            panelRight = new Panel();
            lblWelcome = new Label();
            lblSubtitle = new Label();
            panelDivider = new Panel();
            lblRole = new Label();
            cmbRole = new ComboBox();
            lblUsername = new Label();
            txtUsername = new TextBox();
            lblPassword = new Label();
            txtPassword = new TextBox();
            chkShowPassword = new CheckBox();
            btnLogin = new Button();
            btnClear = new Button();
            lblStatus = new Label();
            lblFooter = new Label();
            panelMain.SuspendLayout();
            panelLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).BeginInit();
            panelRight.SuspendLayout();
            SuspendLayout();
            // 
            // panelMain
            // 
            panelMain.BackColor = Color.FromArgb(15, 20, 40);
            panelMain.Controls.Add(panelLeft);
            panelMain.Controls.Add(panelRight);
            panelMain.Dock = DockStyle.Fill;
            panelMain.Location = new Point(0, 0);
            panelMain.Margin = new Padding(3, 4, 3, 4);
            panelMain.Name = "panelMain";
            panelMain.Size = new Size(1029, 747);
            panelMain.TabIndex = 0;
            // 
            // panelLeft
            // 
            panelLeft.BackColor = Color.FromArgb(0, 122, 204);
            panelLeft.Controls.Add(picLogo);
            panelLeft.Controls.Add(lblBrand);
            panelLeft.Controls.Add(lblTagline);
            panelLeft.Location = new Point(0, 0);
            panelLeft.Margin = new Padding(3, 4, 3, 4);
            panelLeft.Name = "panelLeft";
            panelLeft.Size = new Size(411, 747);
            panelLeft.TabIndex = 0;
            // 
            // picLogo
            // 
            picLogo.Location = new Point(149, 173);
            picLogo.Margin = new Padding(3, 4, 3, 4);
            picLogo.Name = "picLogo";
            picLogo.Size = new Size(114, 133);
            picLogo.SizeMode = PictureBoxSizeMode.Zoom;
            picLogo.TabIndex = 0;
            picLogo.TabStop = false;
            // 
            // lblBrand
            // 
            lblBrand.Font = new Font("Segoe UI", 22F, FontStyle.Bold);
            lblBrand.ForeColor = Color.White;
            lblBrand.Location = new Point(23, 340);
            lblBrand.Name = "lblBrand";
            lblBrand.Size = new Size(366, 67);
            lblBrand.TabIndex = 1;
            lblBrand.Text = "☕ Mel and Friends Café";
            lblBrand.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblTagline
            // 
            lblTagline.Font = new Font("Segoe UI", 10F, FontStyle.Italic);
            lblTagline.ForeColor = Color.FromArgb(200, 230, 255);
            lblTagline.Location = new Point(23, 413);
            lblTagline.Name = "lblTagline";
            lblTagline.Size = new Size(366, 53);
            lblTagline.TabIndex = 2;
            lblTagline.Text = "Internet Cafe Management System";
            lblTagline.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panelRight
            // 
            panelRight.BackColor = Color.FromArgb(22, 30, 55);
            panelRight.Controls.Add(lblWelcome);
            panelRight.Controls.Add(lblSubtitle);
            panelRight.Controls.Add(panelDivider);
            panelRight.Controls.Add(lblRole);
            panelRight.Controls.Add(cmbRole);
            panelRight.Controls.Add(lblUsername);
            panelRight.Controls.Add(txtUsername);
            panelRight.Controls.Add(lblPassword);
            panelRight.Controls.Add(txtPassword);
            panelRight.Controls.Add(chkShowPassword);
            panelRight.Controls.Add(btnLogin);
            panelRight.Controls.Add(btnClear);
            panelRight.Controls.Add(lblStatus);
            panelRight.Controls.Add(lblFooter);
            panelRight.Location = new Point(411, 0);
            panelRight.Margin = new Padding(3, 4, 3, 4);
            panelRight.Name = "panelRight";
            panelRight.Size = new Size(617, 747);
            panelRight.TabIndex = 1;
            // 
            // lblWelcome
            // 
            lblWelcome.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblWelcome.ForeColor = Color.White;
            lblWelcome.Location = new Point(46, 67);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(526, 60);
            lblWelcome.TabIndex = 0;
            lblWelcome.Text = "Welcome Back";
            lblWelcome.Click += this.lblWelcome_Click;
            // 
            // lblSubtitle
            // 
            lblSubtitle.Font = new Font("Segoe UI", 10F);
            lblSubtitle.ForeColor = Color.FromArgb(140, 160, 200);
            lblSubtitle.Location = new Point(46, 131);
            lblSubtitle.Name = "lblSubtitle";
            lblSubtitle.Size = new Size(526, 29);
            lblSubtitle.TabIndex = 1;
            lblSubtitle.Text = "Sign in to manage your café";
            // 
            // panelDivider
            // 
            panelDivider.BackColor = Color.FromArgb(0, 122, 204);
            panelDivider.Location = new Point(46, 171);
            panelDivider.Margin = new Padding(3, 4, 3, 4);
            panelDivider.Name = "panelDivider";
            panelDivider.Size = new Size(69, 4);
            panelDivider.TabIndex = 2;
            // 
            // lblRole
            // 
            lblRole.AutoSize = true;
            lblRole.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblRole.ForeColor = Color.FromArgb(140, 160, 200);
            lblRole.Location = new Point(46, 211);
            lblRole.Name = "lblRole";
            lblRole.Size = new Size(46, 20);
            lblRole.TabIndex = 3;
            lblRole.Text = "ROLE";
            // 
            // cmbRole
            // 
            cmbRole.BackColor = Color.FromArgb(30, 40, 70);
            cmbRole.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbRole.FlatStyle = FlatStyle.Flat;
            cmbRole.Font = new Font("Segoe UI", 11F);
            cmbRole.ForeColor = Color.White;
            cmbRole.FormattingEnabled = true;
            cmbRole.Items.AddRange(new object[] { "Administrator", "Staff / Cashier", "Technician" });
            cmbRole.Location = new Point(46, 240);
            cmbRole.Margin = new Padding(3, 4, 3, 4);
            cmbRole.Name = "cmbRole";
            cmbRole.Size = new Size(525, 33);
            cmbRole.TabIndex = 4;
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblUsername.ForeColor = Color.FromArgb(140, 160, 200);
            lblUsername.Location = new Point(46, 309);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(91, 20);
            lblUsername.TabIndex = 5;
            lblUsername.Text = "USERNAME";
            // 
            // txtUsername
            // 
            txtUsername.BackColor = Color.FromArgb(30, 40, 70);
            txtUsername.BorderStyle = BorderStyle.FixedSingle;
            txtUsername.Font = new Font("Segoe UI", 11F);
            txtUsername.ForeColor = Color.White;
            txtUsername.Location = new Point(46, 339);
            txtUsername.Margin = new Padding(3, 4, 3, 4);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(525, 32);
            txtUsername.TabIndex = 6;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblPassword.ForeColor = Color.FromArgb(140, 160, 200);
            lblPassword.Location = new Point(46, 408);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(91, 20);
            lblPassword.TabIndex = 7;
            lblPassword.Text = "PASSWORD";
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.FromArgb(30, 40, 70);
            txtPassword.BorderStyle = BorderStyle.FixedSingle;
            txtPassword.Font = new Font("Segoe UI", 11F);
            txtPassword.ForeColor = Color.White;
            txtPassword.Location = new Point(46, 437);
            txtPassword.Margin = new Padding(3, 4, 3, 4);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '●';
            txtPassword.Size = new Size(525, 32);
            txtPassword.TabIndex = 8;
            // 
            // chkShowPassword
            // 
            chkShowPassword.AutoSize = true;
            chkShowPassword.BackColor = Color.Transparent;
            chkShowPassword.Font = new Font("Segoe UI", 9F);
            chkShowPassword.ForeColor = Color.FromArgb(140, 160, 200);
            chkShowPassword.Location = new Point(46, 491);
            chkShowPassword.Margin = new Padding(3, 4, 3, 4);
            chkShowPassword.Name = "chkShowPassword";
            chkShowPassword.Size = new Size(132, 24);
            chkShowPassword.TabIndex = 9;
            chkShowPassword.Text = "Show Password";
            chkShowPassword.UseVisualStyleBackColor = false;
            chkShowPassword.CheckedChanged += chkShowPassword_CheckedChanged;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.FromArgb(0, 122, 204);
            btnLogin.Cursor = Cursors.Hand;
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnLogin.ForeColor = Color.White;
            btnLogin.Location = new Point(46, 571);
            btnLogin.Margin = new Padding(3, 4, 3, 4);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(354, 61);
            btnLogin.TabIndex = 11;
            btnLogin.Text = "SIGN IN  →";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.FromArgb(40, 52, 80);
            btnClear.Cursor = Cursors.Hand;
            btnClear.FlatAppearance.BorderSize = 0;
            btnClear.FlatStyle = FlatStyle.Flat;
            btnClear.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnClear.ForeColor = Color.FromArgb(140, 160, 200);
            btnClear.Location = new Point(409, 571);
            btnClear.Margin = new Padding(3, 4, 3, 4);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(162, 61);
            btnClear.TabIndex = 12;
            btnClear.Text = "CLEAR";
            btnClear.UseVisualStyleBackColor = false;
            btnClear.Click += btnClear_Click;
            // 
            // lblStatus
            // 
            lblStatus.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblStatus.ForeColor = Color.FromArgb(255, 80, 80);
            lblStatus.Location = new Point(46, 531);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(526, 29);
            lblStatus.TabIndex = 10;
            lblStatus.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblFooter
            // 
            lblFooter.Font = new Font("Segoe UI", 8.5F);
            lblFooter.ForeColor = Color.FromArgb(70, 90, 130);
            lblFooter.Location = new Point(46, 680);
            lblFooter.Name = "lblFooter";
            lblFooter.Size = new Size(526, 29);
            lblFooter.TabIndex = 13;
            lblFooter.Text = "© 2025 Mel and Friends Cafe — Internet Cafe Management System v1.0";
            lblFooter.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(15, 20, 40);
            ClientSize = new Size(1029, 747);
            Controls.Add(panelMain);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 4, 3, 4);
            MaximizeBox = false;
            Name = "LoginForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "NetZone Café — Login";
            Load += LoginForm_Load;
            panelMain.ResumeLayout(false);
            panelLeft.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)picLogo).EndInit();
            panelRight.ResumeLayout(false);
            panelRight.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        // Control declarations
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.Panel panelRight;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Label lblBrand;
        private System.Windows.Forms.Label lblTagline;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblSubtitle;
        private System.Windows.Forms.Panel panelDivider;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.ComboBox cmbRole;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.CheckBox chkShowPassword;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblFooter;

        public EventHandler lblWelcome_Click { get; private set; }
    }
}