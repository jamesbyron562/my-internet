using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace InternetCafeMS
{
    // ─────────────────────────────────────────────────────────────────────────
    //  LoginForm.cs  |  NetZone Café – Internet Cafe Management System
    //  Handles authentication for Admin, Staff/Cashier, and Technician roles.
    // ─────────────────────────────────────────────────────────────────────────

    public partial class LoginForm : Form
    {
        // ── Attempt limiter ──────────────────────────────────────────────────
        private int _failedAttempts = 0;
        private const int MaxAttempts = 5;

        // ── Sample credentials (replace with DB in production) ───────────────
        // Key = (username.ToLower(), password)  |  Value = role display name
        private readonly Dictionary<(string user, string pass), string> _credentials
            = new Dictionary<(string, string), string>
            {
                { ("admin",     "Admin@123"),  "Administrator"   },
                { ("staff1",    "Staff@001"),  "Staff / Cashier" },
                { ("tech1",     "Tech@001"),   "Technician"      },
            };

        // ────────────────────────────────────────────────────────────────────
        public LoginForm()
        {
            InitializeComponent();
        }

        // ── Form Load ────────────────────────────────────────────────────────
        private void LoginForm_Load(object sender, EventArgs e)
        {
            // Draw a simple monitor icon into the PictureBox as a Bitmap
            DrawLogoIcon();

            // Select the first role by default
            cmbRole.SelectedIndex = 0;

            // Hover effects
            AttachHoverEffect(btnLogin,
                hoverBack: Color.FromArgb(0, 145, 234),
                normalBack: Color.FromArgb(0, 122, 204));

            AttachHoverEffect(btnClear,
                hoverBack: Color.FromArgb(55, 70, 105),
                normalBack: Color.FromArgb(40, 52, 80));

            txtUsername.Focus();
        }

        // ── Draw a simple "monitor" icon using GDI+ ──────────────────────────
        private void DrawLogoIcon()
        {
            var bmp = new Bitmap(100, 100);
            using var g = Graphics.FromImage(bmp);
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            // Outer circle
            using var circleBrush = new SolidBrush(Color.FromArgb(255, 255, 255, 30));
            using var circlePen = new Pen(Color.White, 3f);
            g.FillEllipse(circleBrush, 5, 5, 90, 90);
            g.DrawEllipse(circlePen, 5, 5, 90, 90);

            // Monitor body
            using var monPen = new Pen(Color.White, 2.5f);
            using var monFill = new SolidBrush(Color.FromArgb(0, 122, 204));
            g.FillRectangle(monFill, 22, 28, 56, 34);
            g.DrawRectangle(monPen, 22, 28, 56, 34);

            // Screen glare
            using var glareBrush = new SolidBrush(Color.FromArgb(60, 255, 255, 255));
            g.FillRectangle(glareBrush, 25, 31, 50, 12);

            // Stand
            g.DrawLine(monPen, 50, 62, 50, 74);
            g.DrawLine(monPen, 36, 74, 64, 74);

            // Wi-Fi arc (top-right)
            using var wifiPen = new Pen(Color.FromArgb(200, 255, 255, 255), 2f);
            g.DrawArc(wifiPen, 62, 20, 14, 14, 200, 140);
            g.DrawArc(wifiPen, 66, 24, 6, 6, 200, 140);

            picLogo.Image = bmp;
        }

        // ── Show/Hide Password ───────────────────────────────────────────────
        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = chkShowPassword.Checked ? '\0' : '●';
        }

        // ── Clear Button ─────────────────────────────────────────────────────
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtUsername.Clear();
            txtPassword.Clear();
            lblStatus.Text = "";
            lblStatus.ForeColor = Color.FromArgb(255, 80, 80);
            cmbRole.SelectedIndex = 0;
            txtUsername.Focus();
        }

        // ── Login Button ─────────────────────────────────────────────────────
        private void btnLogin_Click(object sender, EventArgs e)
        {
            // ── Guard: locked out ──────────────────────────────────────────
            if (_failedAttempts >= MaxAttempts)
            {
                ShowStatus("Account locked — too many failed attempts.", isError: true);
                btnLogin.Enabled = false;
                return;
            }

            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;
            string role = cmbRole.SelectedItem?.ToString() ?? "";

            // ── Basic validation ───────────────────────────────────────────
            if (string.IsNullOrEmpty(username))
            {
                ShowStatus("Please enter your username.", isError: true);
                txtUsername.Focus();
                return;
            }
            if (string.IsNullOrEmpty(password))
            {
                ShowStatus("Please enter your password.", isError: true);
                txtPassword.Focus();
                return;
            }

            // ── Authenticate ───────────────────────────────────────────────
            var key = (username.ToLower(), password);

            if (_credentials.TryGetValue(key, out string assignedRole))
            {
                // Check role matches
                if (!assignedRole.Equals(role, StringComparison.OrdinalIgnoreCase))
                {
                    _failedAttempts++;
                    ShowStatus(
                        $"Role mismatch.  ({MaxAttempts - _failedAttempts} attempt(s) left)",
                        isError: true);
                    return;
                }

                // ── SUCCESS ────────────────────────────────────────────────
                _failedAttempts = 0;
                ShowStatus($"✔  Welcome, {username}!  Logged in as {assignedRole}.", isError: false);

                // Log to console (swap for DB/file log in production)
                Console.WriteLine($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}]  LOGIN  user={username}  role={assignedRole}");

                // Short delay so the user sees the success message, then open dashboard
                var timer = new System.Windows.Forms.Timer { Interval = 900 };
                timer.Tick += (s, _) =>
                {
                    timer.Stop();
                    OpenDashboard(username, assignedRole);
                };
                timer.Start();
            }
            else
            {
                _failedAttempts++;
                int remaining = MaxAttempts - _failedAttempts;
                ShowStatus(
                    remaining > 0
                        ? $"Invalid username or password.  ({remaining} attempt(s) left)"
                        : "Account locked — too many failed attempts.",
                    isError: true);

                if (remaining <= 0)
                    btnLogin.Enabled = false;

                txtPassword.Clear();
                txtPassword.Focus();
            }
        }

        // ── Open Dashboard ───────────────────────────────────────────────────
        private void OpenDashboard(string username, string role)
        {
            // Replace this stub with your real dashboard form.
            MessageBox.Show(
                $"Welcome, {username}!\nRole: {role}\n\nDashboard would open here.",
                "Login Successful",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            // Example: uncomment and swap DashboardForm with your actual form class
            // var dashboard = new DashboardForm(username, role);
            // dashboard.Show();
            // this.Hide();
        }

        // ── Helper: show coloured status label ──────────────────────────────
        private void ShowStatus(string message, bool isError)
        {
            lblStatus.ForeColor = isError
                ? Color.FromArgb(255, 80, 80)
                : Color.FromArgb(80, 220, 120);
            lblStatus.Text = message;
        }

        // ── Helper: button hover glow ────────────────────────────────────────
        private void AttachHoverEffect(Button btn, Color hoverBack, Color normalBack)
        {
            btn.MouseEnter += (s, e) => btn.BackColor = hoverBack;
            btn.MouseLeave += (s, e) => btn.BackColor = normalBack;
        }

        // ── Allow Enter key to submit ─────────────────────────────────────────
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Enter)
            {
                btnLogin_Click(this, EventArgs.Empty);
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}