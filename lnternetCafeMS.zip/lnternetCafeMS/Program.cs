using System;
using System.Windows.Forms;

namespace InternetCafeMS
{
    // ─────────────────────────────────────────────────────────────────────────
    //  Program.cs  |  NetZone Café – Internet Cafe Management System
    //  Application entry point.
    // ─────────────────────────────────────────────────────────────────────────

    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            // Enable modern Windows visual styles
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // (Optional) Global exception handler — logs unhandled UI-thread errors
            Application.ThreadException += (sender, e) =>
            {
                MessageBox.Show(
                    $"An unexpected error occurred:\n\n{e.Exception.Message}",
                    "NetZone Café – Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            };

            // Start the application on the Login form
            Application.Run(new LoginForm());
        }
    }
}